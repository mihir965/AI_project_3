from setuptools import setup, find_packages

setup(name="ai_proj_3", version="1.0", packages=find_packages())